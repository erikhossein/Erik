from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def cart_detail(request):
    return render(request, 'cart/detail.html')
