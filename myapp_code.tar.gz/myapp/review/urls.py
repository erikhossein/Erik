from django.urls import path
from . import views

urlpatterns = [
    path('product/<int:product_id>/', views.add_product_review, name='add_product_review'),
    path('seller/<int:seller_id>/', views.add_seller_review, name='add_seller_review'),
]
