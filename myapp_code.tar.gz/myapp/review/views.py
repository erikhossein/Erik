from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Review, SellerReview
from Product.models import Product
from accounts.models import User

@login_required
def add_product_review(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    
    if request.method == 'POST':
        rating = int(request.POST.get('rating'))
        comment = request.POST.get('comment')
        
        existing = Review.objects.filter(user=request.user, product=product).first()
        if existing:
            messages.error(request, 'شما قبلاً برای این محصول نظر داده‌اید')
        else:
            Review.objects.create(
                user=request.user,
                product=product,
                rating=rating,
                comment=comment
            )
            messages.success(request, 'نظر شما با موفقیت ثبت شد')
        
        return redirect('product_detail', product_id=product.id)
    
    return render(request, 'review/add_product_review.html', {'product': product})

@login_required
def add_seller_review(request, seller_id):
    seller = get_object_or_404(User, id=seller_id, role='seller')
    
    if request.method == 'POST':
        rating = int(request.POST.get('rating'))
        comment = request.POST.get('comment')
        
        existing = SellerReview.objects.filter(user=request.user, seller=seller).first()
        if existing:
            messages.error(request, 'شما قبلاً برای این فروشنده نظر داده‌اید')
        else:
            SellerReview.objects.create(
                user=request.user,
                seller=seller,
                rating=rating,
                comment=comment
            )
            messages.success(request, 'نظر شما با موفقیت ثبت شد')
        
        return redirect('seller_profile', seller_id=seller.id)
    
    return render(request, 'review/add_seller_review.html', {'seller': seller})
