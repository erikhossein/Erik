from django.urls import path
from . import views

urlpatterns = [
    path('change-password/', views.change_password, name='change_password'),
    path('addresses/delete/<int:address_id>/', views.address_delete, name='address_delete'),
    path('addresses/', views.addresses, name='buyer_addresses'),
    path('wallet/', views.wallet, name='buyer_wallet'),
    path('orders/', views.orders, name='buyer_orders'),
    path('', views.dashboard, name='buyer_dashboard'),
    path('profile/', views.profile, name='buyer_profile'),
    path('cart/', views.cart_detail, name='buyer_cart'),
]
