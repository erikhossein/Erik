from django.apps import AppConfig


class BuyerPanelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'buyer_panel'
