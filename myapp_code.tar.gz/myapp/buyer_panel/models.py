from django.db import models

# Create your models here.

class Address(models.Model):
    user = models.ForeignKey('accounts.User', on_delete=models.CASCADE, related_name='addresses')
    full_name = models.CharField(max_length=100)
    province = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    address = models.TextField()
    postal_code = models.CharField(max_length=20)
    phone = models.CharField(max_length=15)
    is_default = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.full_name} - {self.city}"
