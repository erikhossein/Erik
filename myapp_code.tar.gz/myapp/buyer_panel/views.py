from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from cart.models import Cart

@login_required
def dashboard(request):
    if request.user.role != 'buyer':
        return redirect('/')
    return render(request, 'buyer_panel/dashboard.html')

@login_required
def profile(request):
    if request.user.role != 'buyer':
        return redirect('/')
    
    if request.method == 'POST':
        request.user.first_name = request.POST.get('first_name', '')
        request.user.last_name = request.POST.get('last_name', '')
        request.user.phone = request.POST.get('phone', '')
        request.user.save()
        messages.success(request, 'پروفایل با موفقیت ویرایش شد')
        return redirect('buyer_profile')
    
    return render(request, 'buyer_panel/profile.html', {'user': request.user})

@login_required
def cart_detail(request):
    if request.user.role != 'buyer':
        return redirect('/')
    
    cart, created = Cart.objects.get_or_create(user=request.user)
    return render(request, 'buyer_panel/cart.html', {'cart': cart})

@login_required
def order_detail(request, order_id):
    from orders.models import Order
    if request.user.role != 'buyer':
        return redirect('/')
    
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, 'buyer_panel/order_detail.html', {'order': order})

def orders(request):
    from orders.models import Order
    if request.user.role != 'buyer':
        return redirect('/')
    orders_list = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'buyer_panel/orders.html', {'orders': orders_list})

def wallet(request):
    if request.user.role != 'buyer':
        return redirect('/')
    return render(request, 'buyer_panel/wallet.html', {'user': request.user})

def addresses(request):
    if request.user.role != 'buyer':
        return redirect('/')
    return render(request, 'buyer_panel/addresses.html', {'user': request.user})

def wallet(request):
    from wallet.models import WalletTransaction
    if request.user.role != 'buyer':
        return redirect('/')
    
    balance = request.user.wallet
    transactions = WalletTransaction.objects.filter(user=request.user).order_by('-created_at')
    
    if request.method == 'POST':
        amount = int(request.POST.get('amount'))
        if amount > 0:
            request.user.wallet += amount
            request.user.save()
            WalletTransaction.objects.create(
                user=request.user,
                amount=amount,
                transaction_type='deposit',
                description='شارژ کیف پول'
            )
            messages.success(request, f'مبلغ {amount} تومان با موفقیت شارژ شد')
        else:
            messages.error(request, 'مبلغ باید بیشتر از صفر باشد')
        return redirect('buyer_wallet')
    
    context = {
        'balance': balance,
        'transactions': transactions,
    }
    return render(request, 'buyer_panel/wallet.html', context)

def addresses(request):
    from .models import Address
    if request.user.role != 'buyer':
        return redirect('/')
    
    if request.method == 'POST':
        address = Address.objects.create(
            user=request.user,
            full_name=request.POST.get('full_name'),
            province=request.POST.get('province'),
            city=request.POST.get('city'),
            address=request.POST.get('address'),
            postal_code=request.POST.get('postal_code'),
            phone=request.POST.get('phone'),
            is_default=request.POST.get('is_default') == 'on'
        )
        if address.is_default:
            Address.objects.filter(user=request.user).exclude(id=address.id).update(is_default=False)
        messages.success(request, 'آدرس با موفقیت اضافه شد')
        return redirect('buyer_addresses')
    
    addresses = Address.objects.filter(user=request.user)
    return render(request, 'buyer_panel/addresses.html', {'addresses': addresses})

def address_delete(request, address_id):
    from .models import Address
    address = Address.objects.get(id=address_id, user=request.user)
    address.delete()
    messages.success(request, 'آدرس با موفقیت حذف شد')
    return redirect('buyer_addresses')

def change_password(request):
    if request.user.role != 'buyer':
        return redirect('/')
    
    error = None
    success = None
    
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        
        if not request.user.check_password(old_password):
            error = 'رمز عبور فعلی اشتباه است'
        elif new_password != confirm_password:
            error = 'رمز عبور جدید و تکرار آن مطابقت ندارد'
        elif len(new_password) < 6:
            error = 'رمز عبور جدید باید حداقل 6 کاراکتر باشد'
        else:
            request.user.set_password(new_password)
            request.user.save()
            from django.contrib.auth import update_session_auth_hash
            update_session_auth_hash(request, request.user)
            success = 'رمز عبور با موفقیت تغییر کرد'
    
    return render(request, 'buyer_panel/change_password.html', {'error': error, 'success': success})
