from django.shortcuts import render, redirect
from django.contrib.admin.views.decorators import staff_member_required
from django.core.exceptions import PermissionDenied
from django.contrib import messages
from .models import SiteSettings, Slider, MenuItem, NetworkSettings, Theme
from .forms import SiteSettingsForm, SliderForm, MenuItemForm, NetworkSettingsForm, ThemeForm
from Product.models import Product
from accounts.models import User
from orders.models import Order
import os

def superadmin_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('/super-admin-login/')
        if not request.user.is_superuser:
            raise PermissionDenied
        return view_func(request, *args, **kwargs)
    return wrapper

@staff_member_required
def admin_dashboard(request):
    total_products = Product.objects.count()
    total_users = User.objects.count()
    total_sellers = User.objects.filter(role='seller').count()
    total_buyers = User.objects.filter(role='buyer').count()
    total_orders = Order.objects.count()
    
    context = {
        'total_products': total_products,
        'total_users': total_users,
        'total_sellers': total_sellers,
        'total_buyers': total_buyers,
        'total_orders': total_orders,
    }
    return render(request, 'custom_admin/dashboard.html', context)

@staff_member_required
def site_settings_view(request):
    settings = SiteSettings.objects.first()
    if not settings:
        settings = SiteSettings.objects.create()
    
    if request.method == 'POST':
        form = SiteSettingsForm(request.POST, request.FILES, instance=settings)
        if form.is_valid():
            form.save()
            messages.success(request, 'تنظیمات با موفقیت ذخیره شد')
            return redirect('admin_settings')
    else:
        form = SiteSettingsForm(instance=settings)
    
    return render(request, 'custom_admin/settings.html', {'form': form})

@staff_member_required
def slider_list(request):
    sliders = Slider.objects.all()
    return render(request, 'custom_admin/slider_list.html', {'sliders': sliders})

@staff_member_required
def slider_add(request):
    if request.method == 'POST':
        form = SliderForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'اسلایدر با موفقیت اضافه شد')
            return redirect('admin_sliders')
    else:
        form = SliderForm()
    return render(request, 'custom_admin/slider_form.html', {'form': form, 'title': 'افزودن اسلایدر'})

@staff_member_required
def slider_edit(request, slider_id):
    slider = Slider.objects.get(id=slider_id)
    if request.method == 'POST':
        form = SliderForm(request.POST, request.FILES, instance=slider)
        if form.is_valid():
            form.save()
            messages.success(request, 'اسلایدر با موفقیت ویرایش شد')
            return redirect('admin_sliders')
    else:
        form = SliderForm(instance=slider)
    return render(request, 'custom_admin/slider_form.html', {'form': form, 'title': 'ویرایش اسلایدر'})

@staff_member_required
def slider_delete(request, slider_id):
    slider = Slider.objects.get(id=slider_id)
    slider.delete()
    messages.success(request, 'اسلایدر با موفقیت حذف شد')
    return redirect('admin_sliders')

@staff_member_required
def menu_list(request):
    menus = MenuItem.objects.filter(parent=None)
    return render(request, 'custom_admin/menu_list.html', {'menus': menus})

@staff_member_required
def menu_add(request):
    if request.method == 'POST':
        form = MenuItemForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'منو با موفقیت اضافه شد')
            return redirect('admin_menus')
    else:
        form = MenuItemForm()
    return render(request, 'custom_admin/menu_form.html', {'form': form, 'title': 'افزودن منو'})

@staff_member_required
def menu_edit(request, menu_id):
    menu = MenuItem.objects.get(id=menu_id)
    if request.method == 'POST':
        form = MenuItemForm(request.POST, instance=menu)
        if form.is_valid():
            form.save()
            messages.success(request, 'منو با موفقیت ویرایش شد')
            return redirect('admin_menus')
    else:
        form = MenuItemForm(instance=menu)
    return render(request, 'custom_admin/menu_form.html', {'form': form, 'title': 'ویرایش منو'})

@staff_member_required
def menu_delete(request, menu_id):
    menu = MenuItem.objects.get(id=menu_id)
    menu.delete()
    messages.success(request, 'منو با موفقیت حذف شد')
    return redirect('admin_menus')

@superadmin_required
def admin_users_list(request):
    admins = User.objects.filter(is_staff=True)
    return render(request, 'custom_admin/admin_users.html', {'admins': admins})

@superadmin_required
def admin_user_add(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        user = User.objects.create_user(username=username, password=password, email=email)
        user.is_staff = True
        if request.POST.get('is_superuser'):
            user.is_superuser = True
        user.save()
        messages.success(request, 'ادمین جدید اضافه شد')
        return redirect('admin_users')
    return render(request, 'custom_admin/admin_user_form.html', {'title': 'افزودن ادمین'})

@superadmin_required
def admin_user_delete(request, user_id):
    user = User.objects.get(id=user_id)
    if user == request.user:
        messages.error(request, 'نمی‌توانید خودتان را حذف کنید')
    else:
        user.delete()
        messages.success(request, 'ادمین حذف شد')
    return redirect('admin_users')

@staff_member_required
def all_users_list(request):
    users = User.objects.all().exclude(is_staff=True)
    return render(request, 'custom_admin/all_users.html', {'users': users})

@staff_member_required
def user_delete(request, user_id):
    user = User.objects.get(id=user_id)
    if user.is_superuser:
        messages.error(request, 'نمی‌توانید سوپرادمین را حذف کنید')
    elif user == request.user:
        messages.error(request, 'نمی‌توانید خودتان را حذف کنید')
    else:
        user.delete()
        messages.success(request, 'کاربر با موفقیت حذف شد')
    return redirect('all_users')

@superadmin_required
def view_logs(request):
    log_file = '/home/eriksportir/myapp/stderr.log'
    logs = ""
    if os.path.exists(log_file):
        with open(log_file, 'r') as f:
            logs = f.read()[-5000:]
    return render(request, 'custom_admin/logs.html', {'logs': logs})

@superadmin_required
def network_settings_view(request):
    settings = NetworkSettings.objects.first()
    if not settings:
        settings = NetworkSettings.objects.create()
    
    if request.method == 'POST':
        form = NetworkSettingsForm(request.POST, request.FILES, instance=settings)
        if form.is_valid():
            form.save()
            messages.success(request, 'تنظیمات شبکه با موفقیت ذخیره شد')
            return redirect('network_settings')
    else:
        form = NetworkSettingsForm(instance=settings)
    
    return render(request, 'custom_admin/network_settings.html', {'form': form})

@superadmin_required
def theme_list(request):
    themes = Theme.objects.all()
    return render(request, 'custom_admin/theme_list.html', {'themes': themes})

@superadmin_required
def theme_add(request):
    if request.method == 'POST':
        form = ThemeForm(request.POST, request.FILES)
        if form.is_valid():
            theme = form.save()
            if theme.is_active:
                Theme.objects.exclude(id=theme.id).update(is_active=False)
            messages.success(request, 'قالب با موفقیت اضافه شد')
            return redirect('theme_list')
    else:
        form = ThemeForm()
    return render(request, 'custom_admin/theme_form.html', {'form': form, 'title': 'افزودن قالب'})

@superadmin_required
def theme_edit(request, theme_id):
    theme = Theme.objects.get(id=theme_id)
    if request.method == 'POST':
        form = ThemeForm(request.POST, request.FILES, instance=theme)
        if form.is_valid():
            theme = form.save()
            if theme.is_active:
                Theme.objects.exclude(id=theme.id).update(is_active=False)
            messages.success(request, 'قالب با موفقیت ویرایش شد')
            return redirect('theme_list')
    else:
        form = ThemeForm(instance=theme)
    return render(request, 'custom_admin/theme_form.html', {'form': form, 'title': 'ویرایش قالب'})

@superadmin_required
def theme_delete(request, theme_id):
    theme = Theme.objects.get(id=theme_id)
    theme.delete()
    messages.success(request, 'قالب با موفقیت حذف شد')
    return redirect('theme_list')

@superadmin_required
def theme_activate(request, theme_id):
    Theme.objects.all().update(is_active=False)
    theme = Theme.objects.get(id=theme_id)
    theme.is_active = True
    theme.save()
    messages.success(request, f'قالب {theme.name} فعال شد')
    return redirect('theme_list')
from .models import Page
from .forms import PageForm

@staff_member_required
def page_list(request):
    pages = Page.objects.all()
    return render(request, 'custom_admin/page_list.html', {'pages': pages})

@staff_member_required
def page_add(request):
    if request.method == 'POST':
        form = PageForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'صفحه با موفقیت اضافه شد')
            return redirect('page_list')
    else:
        form = PageForm()
    return render(request, 'custom_admin/page_form.html', {'form': form, 'title': 'افزودن صفحه جدید'})

@staff_member_required
def page_edit(request, page_id):
    page = Page.objects.get(id=page_id)
    if request.method == 'POST':
        form = PageForm(request.POST, instance=page)
        if form.is_valid():
            form.save()
            messages.success(request, 'صفحه با موفقیت ویرایش شد')
            return redirect('page_list')
    else:
        form = PageForm(instance=page)
    return render(request, 'custom_admin/page_form.html', {'form': form, 'title': 'ویرایش صفحه'})

@staff_member_required
def page_delete(request, page_id):
    page = Page.objects.get(id=page_id)
    page.delete()
    messages.success(request, 'صفحه با موفقیت حذف شد')
    return redirect('page_list')
