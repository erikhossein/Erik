from django.db import models

class SiteSettings(models.Model):
    site_name = models.CharField(max_length=100, default='فروشگاه من')
    logo = models.ImageField(upload_to='site/', blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, default='')
    email = models.EmailField(blank=True, default='')
    address = models.TextField(blank=True, default='')
    about_text = models.TextField(blank=True, default='')
    
    def __str__(self):
        return self.site_name

class Slider(models.Model):
    title = models.CharField(max_length=200)
    subtitle = models.CharField(max_length=300, blank=True, default='')
    image = models.ImageField(upload_to='slider/')
    button_text = models.CharField(max_length=50, blank=True, default='')
    button_link = models.CharField(max_length=200, blank=True, default='')
    order = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['order']
    
    def __str__(self):
        return self.title

class MenuItem(models.Model):
    title = models.CharField(max_length=100)
    url = models.CharField(max_length=200)
    order = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True)
    
    class Meta:
        ordering = ['order']
    
    def __str__(self):
        return self.title

class FAQ(models.Model):
    question = models.CharField(max_length=300)
    answer = models.TextField()
    order = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['order']
    
    def __str__(self):
        return self.question

class NetworkSettings(models.Model):
    site_name = models.CharField(max_length=100, default='فروشگاه من')
    site_description = models.TextField(blank=True, default='')
    logo = models.ImageField(upload_to='site/', blank=True, null=True)
    favicon = models.ImageField(upload_to='site/', blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, default='')
    email = models.EmailField(blank=True, default='')
    address = models.TextField(blank=True, default='')
    enable_registration = models.BooleanField(default=True)
    enable_seller_registration = models.BooleanField(default=True)
    min_password_length = models.IntegerField(default=6)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.site_name
    
    class Meta:
        verbose_name = 'تنظیمات شبکه'
        verbose_name_plural = 'تنظیمات شبکه'

class Theme(models.Model):
    name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=False)
    primary_color = models.CharField(max_length=20, default='#007bff')
    secondary_color = models.CharField(max_length=20, default='#6c757d')
    font_family = models.CharField(max_length=100, default='Tahoma')
    logo = models.ImageField(upload_to='themes/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name

class Page(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    content = models.TextField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title
