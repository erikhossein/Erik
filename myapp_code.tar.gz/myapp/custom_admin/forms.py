from django import forms
from .models import SiteSettings, Slider, MenuItem, NetworkSettings, Theme, Page

class SiteSettingsForm(forms.ModelForm):
    class Meta:
        model = SiteSettings
        fields = ['site_name', 'logo', 'phone', 'email', 'address', 'about_text']

class SliderForm(forms.ModelForm):
    class Meta:
        model = Slider
        fields = ['title', 'subtitle', 'image', 'button_text', 'button_link', 'order', 'is_active']

class MenuItemForm(forms.ModelForm):
    class Meta:
        model = MenuItem
        fields = ['title', 'url', 'order', 'is_active', 'parent']

class NetworkSettingsForm(forms.ModelForm):
    class Meta:
        model = NetworkSettings
        fields = '__all__'
        widgets = {
            'site_description': forms.Textarea(attrs={'rows': 3}),
            'address': forms.Textarea(attrs={'rows': 3}),
        }

class ThemeForm(forms.ModelForm):
    class Meta:
        model = Theme
        fields = ['name', 'is_active', 'primary_color', 'secondary_color', 'font_family', 'logo']

class PageForm(forms.ModelForm):
    class Meta:
        model = Page
        fields = ['title', 'slug', 'content', 'is_active']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 10}),
        }
