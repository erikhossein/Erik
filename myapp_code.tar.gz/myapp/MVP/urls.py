from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('wishlist/', views.wishlist, name='wishlist'),
    path('wishlist/add/<int:product_id>/', views.add_to_wishlist, name='add_to_wishlist'),
    path('', views.home, name='home'),
    path('products/', views.product_list, name='products'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('admin/', admin.site.urls),
    path('authentication/', include('AuthenticationSystem.urls')),
    path('product/', include('Product.urls')),
    path('document/', include('Document.urls')),
    path('seller/', include('seller_panel.urls')),
    path('custom-admin/', include('custom_admin.urls')),
    path('cart/', include('cart.urls')),
    path('buyer/', include('buyer_panel.urls')),
    path('login/', views.user_login, name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('seller-login/', views.seller_login, name='seller_login'),
    path('seller-register/', views.seller_register, name='seller_register'),
    path('admin-login/', views.admin_login, name='admin_login'),
    path('super-admin-login/', views.super_admin_login, name='super_admin_login'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('profile/<str:username>/', views.public_profile, name='public_profile'),
    path('sellers/', views.sellers_list, name='sellers_list'),
    path('@<str:username>/', views.seller_store, name='seller_store'),
    path('search/', views.advanced_search, name='advanced_search'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
