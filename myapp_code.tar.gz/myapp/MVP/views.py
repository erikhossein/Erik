from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db.models import Sum, Count
from django.utils import timezone
from datetime import timedelta
from Product.models import Product, Industry
from accounts.models import User
from custom_admin.models import Slider, FAQ
from orders.models import OrderItem

def home(request):
    from Product.models import ProductView
    popular_products = Product.objects.annotate(view_count=Count("views")).order_by("-view_count")[:8]
    sliders = Slider.objects.filter(is_active=True)
    
    # پرفروش‌ترین محصولات
    top_products = OrderItem.objects.values('product').annotate(
        total=Sum('quantity')
    ).order_by('-total')[:10]
    product_ids = [item['product'] for item in top_products]
    best_selling = Product.objects.filter(id__in=product_ids)
    
    # محصولات ویژه
    featured_products = Product.objects.filter(is_featured=True, active=True)[:8]
    
    # محصولات تخفیف‌دار
    discounted = Product.objects.filter(discount_percent__gt=0)[:5]
    
    # فروشنده‌های برتر
    top_sellers = User.objects.filter(role='seller')[:3]
    
    # سوالات متداول
    faqs = FAQ.objects.filter(is_active=True)
    
    context = {
        'popular_products': popular_products,
        'sliders': sliders,
        'best_selling': best_selling,
        'featured_products': featured_products,
        'discounted': discounted,
        'top_sellers': top_sellers,
        'faqs': faqs,
    }
    return render(request, 'home.html', context)

def product_list(request):
    q = request.GET.get('q', '')
    products = Product.objects.filter(active=True)
    if q:
        products = products.filter(title__icontains=q)
    return render(request, 'products.html', {'products': products})

def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id, active=True)
    similar = Product.objects.filter(industry=product.industry, active=True).exclude(id=product.id)[:4]
    context = {
        'popular_products': popular_products,
        'product': product,
        'similar': similar,
    }
    return render(request, 'product_detail.html', context)

def user_login(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            if user.role == 'seller':
                return redirect('/seller/')
            elif user.role == 'admin':
                return redirect('/custom-admin/')
            else:
                return redirect('/products/')
        else:
            error = 'نام کاربری یا رمز عبور اشتباه است'
    return render(request, 'login.html', {'error': error})

def logout_view(request):
    logout(request)
    return redirect('/login/')

def register(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm = request.POST.get('confirm_password')
        
        if password != confirm:
            error = 'رمز عبور و تکرار آن مطابقت ندارد'
        elif User.objects.filter(username=username).exists():
            error = 'این نام کاربری قبلاً ثبت شده است'
        else:
            try:
                validate_password(password)
            except ValidationError as validation_errors:
                error = ' '.join(validation_errors.messages)
                return render(request, 'register.html', {'error': error})
            
            user = User.objects.create_user(username=username, password=password, role='buyer')
            login(request, user)
            return redirect('/buyer/')
    
    return render(request, 'register.html', {'error': error})

def seller_login(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user and user.role == 'seller':
            login(request, user)
            return redirect('/seller/')
        else:
            error = 'نام کاربری یا رمز عبور اشتباه است'
    return render(request, 'seller_login.html', {'error': error})

def seller_register(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        shop_name = request.POST.get('shop_name')
        
        if User.objects.filter(username=username).exists():
            error = 'نام کاربری تکراری است'
        else:
            try:
                validate_password(password)
            except ValidationError as validation_errors:
                error = ' '.join(validation_errors.messages)
                return render(request, 'seller_register.html', {'error': error})
            
            user = User.objects.create_user(username=username, password=password, role='seller')
            from seller_panel.models import SellerProfile
            SellerProfile.objects.create(user=user, shop_name=shop_name, balance=0, total_sales=0, total_products_sold=0, rating=0)
            login(request, user)
            return redirect('/seller/')
    return render(request, 'seller_register.html', {'error': error})

def admin_login(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user and user.is_superuser:
            login(request, user)
            return redirect('/custom-admin/')
        else:
            error = 'دسترسی غیرمجاز'
    return render(request, 'admin_login.html', {'error': error})

def super_admin_login(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user and user.is_superuser:
            login(request, user)
            return redirect('/custom-admin/')
        else:
            error = 'دسترسی غیرمجاز'
    return render(request, 'super_admin_login.html', {'error': error})

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def public_profile(request, username):
    user = get_object_or_404(User, username=username)
    return render(request, 'public_profile.html', {'user': user})

def sellers_list(request):
    sellers = User.objects.filter(role='seller')
    return render(request, 'sellers_list.html', {'sellers': sellers})

def seller_store(request, username):
    seller = get_object_or_404(User, username=username, role='seller')
    products = Product.objects.filter(store_owner=seller, active=True)
    from seller_panel.models import SellerProfile
    profile = SellerProfile.objects.filter(user=seller).first()
    context = {
        'popular_products': popular_products,
        'seller': seller,
        'products': products,
        'profile': profile,
        'total_products': products.count(),
    }
    return render(request, 'seller_store.html', context)

def advanced_search(request):
    q = request.GET.get('q', '')
    category = request.GET.get('category', '')
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')
    
    products = Product.objects.filter(active=True)
    if q:
        products = products.filter(title__icontains=q)
    if category:
        products = products.filter(industry_id=category)
    if min_price:
        products = products.filter(price__gte=min_price)
    if max_price:
        products = products.filter(price__lte=max_price)
    
    categories = Industry.objects.filter(parent=None)
    
    context = {
        'popular_products': popular_products,
        'products': products,
        'categories': categories,
        'q': q,
        'selected_category': category,
        'min_price': min_price,
        'max_price': max_price,
    }
    return render(request, 'advanced_search.html', context)

def categories_processor(request):
    return {'categories': Industry.objects.filter(parent=None)}

def record_view(product, request):
    from Product.models import ProductView
    ip = request.META.get('REMOTE_ADDR')
    session_key = request.session.session_key
    ProductView.objects.create(product=product, ip=ip, session_key=session_key)
from accounts.models import Wishlist

def add_to_wishlist(request, product_id):
    if not request.user.is_authenticated:
        return redirect('/login/')
    
    product = get_object_or_404(Product, id=product_id)
    wishlist_item, created = Wishlist.objects.get_or_create(
        user=request.user,
        product=product
    )
    
    if created:
        messages.success(request, 'محصول به لیست علاقه‌مندی اضافه شد')
    else:
        messages.info(request, 'این محصول قبلاً در لیست علاقه‌مندی شماست')
    
    return redirect('product_detail', product_id=product.id)

def wishlist(request):
    if not request.user.is_authenticated:
        return redirect('/login/')
    
    wishlist_items = Wishlist.objects.filter(user=request.user)
    return render(request, 'wishlist.html', {'wishlist_items': wishlist_items})
