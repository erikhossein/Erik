import os
import sys

# Add your project directory to the path
sys.path.insert(0, '/home/eriksportir/myapp')

# Set Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'MVP.settings')

# Create WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
