from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.contrib import messages
from django.db.models import Sum, Count
from .models import SellerProfile
from .forms import SellerProfileForm, ProductForm
from Product.models import Product
from orders.models import OrderItem, Order

def seller_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('/seller-login/')
        if request.user.role != 'seller':
            raise PermissionDenied
        return view_func(request, *args, **kwargs)
    return wrapper

@login_required
@seller_required

@login_required
@seller_required
def edit_profile(request):
    profile, created = SellerProfile.objects.get_or_create(user=request.user)
    
    if request.method == 'POST':
        form = SellerProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'پروفایل با موفقیت ذخیره شد')
            return redirect('seller_dashboard')
    else:
        form = SellerProfileForm(instance=profile)
    
    return render(request, 'seller_panel/edit_profile.html', {'form': form})

@login_required
@seller_required

@login_required
@seller_required
def edit_product(request, product_id):
    product = Product.objects.get(id=product_id, store_owner=request.user)
    
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, 'محصول با موفقیت ویرایش شد')
            return redirect('seller_dashboard')
    else:
        form = ProductForm(instance=product)
    
    return render(request, 'seller_panel/edit_product.html', {'form': form, 'product': product})

@login_required
@seller_required
def delete_product(request, product_id):
    product = Product.objects.get(id=product_id, store_owner=request.user)
    product.delete()
    messages.success(request, 'محصول با موفقیت حذف شد')
    return redirect('seller_dashboard')

@login_required
@seller_required
def seller_orders(request):
    order_items = OrderItem.objects.filter(product__store_owner=request.user)
    order_ids = order_items.values_list('order_id', flat=True).distinct()
    orders = Order.objects.filter(id__in=order_ids).order_by('-created_at')
    return render(request, 'seller_panel/orders.html', {'orders': orders})
from django.db.models import Sum, Count
from django.utils import timezone
from datetime import timedelta
import json

@login_required
@seller_required
def sales_chart_data(request):
    # فروش 7 روز اخیر
    end_date = timezone.now()
    start_date = end_date - timedelta(days=30)
    
    # دریافت سفارشات فروشنده
    from orders.models import OrderItem
    items = OrderItem.objects.filter(product__store_owner=request.user, order__created_at__gte=start_date)
    
    # گروه‌بندی روزانه
    daily_sales = {}
    for i in range(30):
        day = start_date + timedelta(days=i)
        day_str = day.strftime('%Y-%m-%d')
        total = items.filter(order__created_at__date=day).aggregate(total=Sum('price'))['total'] or 0
        daily_sales[day_str] = float(total)
    
    return JsonResponse({
        'labels': list(daily_sales.keys()),
        'data': list(daily_sales.values())
    })
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.contrib import messages
from django.db.models import Sum, Count
from django.utils import timezone
from datetime import timedelta
from .models import SellerProfile
from .forms import SellerProfileForm, ProductForm
from Product.models import Product
from orders.models import OrderItem, Order

def seller_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('/seller-login/')
        if request.user.role != 'seller':
            raise PermissionDenied
        return view_func(request, *args, **kwargs)
    return wrapper

@login_required
@seller_required
def seller_dashboard(request):
    profile, created = SellerProfile.objects.get_or_create(user=request.user)
    
    products = Product.objects.filter(store_owner=request.user)
    total_products = products.count()
    out_of_stock = products.filter(stock=0).count()
    
    order_items = OrderItem.objects.filter(product__store_owner=request.user)
    total_orders = order_items.count()
    total_sales = order_items.aggregate(total=Sum('price'))['total'] or 0
    total_quantity = order_items.aggregate(total=Sum('quantity'))['total'] or 0
    
    recent_orders = Order.objects.filter(items__product__store_owner=request.user).distinct().order_by('-created_at')[:10]
    
    profile.total_sales = total_sales
    profile.total_products_sold = total_quantity
    profile.save()
    
    # داده‌های نمودار فروش 30 روز اخیر
    end_date = timezone.now()
    start_date = end_date - timedelta(days=30)
    seller_items = OrderItem.objects.filter(product__store_owner=request.user, order__created_at__range=[start_date, end_date])
    
    sales_data = {}
    for i in range(30):
        day = start_date.date() + timedelta(days=i)
        total = seller_items.filter(order__created_at__date=day).aggregate(total=Sum('price'))['total'] or 0
        sales_data[day.strftime('%Y-%m-%d')] = float(total)
    
    chart_data = {
        'labels': list(sales_data.keys()),
        'values': list(sales_data.values()),
    }
    
    context = {
        'profile': profile,
        'products': products[:10],
        'total_products': total_products,
        'out_of_stock': out_of_stock,
        'total_orders': total_orders,
        'total_sales': total_sales,
        'total_quantity': total_quantity,
        'recent_orders': recent_orders,
        'chart_data': chart_data,
    }
    return render(request, 'seller_panel/dashboard.html', context)

# بقیه توابع (edit_profile, add_product, edit_product, delete_product, seller_orders) به همین شکل قبلی می‌مانند

@login_required
@seller_required
def manage_stock(request):
    products = Product.objects.filter(store_owner=request.user)
    
    if request.method == 'POST':
        for product in products:
            new_stock = request.POST.get(f'stock_{product.id}')
            if new_stock is not None:
                product.stock = int(new_stock)
                product.save()
        messages.success(request, 'موجودی محصولات با موفقیت به‌روزرسانی شد')
        return redirect('manage_stock')
    
    return render(request, 'seller_panel/manage_stock.html', {'products': products})
from django.utils import timezone
from datetime import timedelta
import json

@login_required
@seller_required
def sales_chart(request):
    end_date = timezone.now()
    start_date = end_date - timedelta(days=30)
    
    # داده‌های فروش 30 روز اخیر
    sales_data = []
    dates = []
    
    for i in range(30):
        day = start_date + timedelta(days=i)
        dates.append(day.strftime('%Y-%m-%d'))
        
        # جمع فروش در این روز
        total = OrderItem.objects.filter(
            product__store_owner=request.user,
            order__created_at__date=day
        ).aggregate(total=Sum('price'))['total'] or 0
        sales_data.append(float(total))
    
    context = {
        'dates': json.dumps(dates),
        'sales_data': json.dumps(sales_data),
    }
    return render(request, 'seller_panel/sales_chart.html', context)

def change_password(request):
    if request.user.role != 'seller':
        return redirect('/')
    
    error = None
    success = None
    
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        
        if not request.user.check_password(old_password):
            error = 'رمز عبور فعلی اشتباه است'
        elif new_password != confirm_password:
            error = 'رمز عبور جدید و تکرار آن مطابقت ندارد'
        elif len(new_password) < 8:
            error = 'رمز عبور جدید باید حداقل 8 کاراکتر باشد'
        else:
            request.user.set_password(new_password)
            request.user.save()
            from django.contrib.auth import update_session_auth_hash
            update_session_auth_hash(request, request.user)
            success = 'رمز عبور با موفقیت تغییر کرد'
    
    return render(request, 'seller_panel/change_password.html', {'error': error, 'success': success})
@login_required
@seller_required
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)
            product.store_owner = request.user
            product.save()
            
            # ذخیره تصاویر
            images = request.FILES.getlist('images')
            for i, img in enumerate(images):
                is_main = (i == 0)
                ProductImage.objects.create(
                    product=product,
                    image=img,
                    is_main=is_main
                )
            
            messages.success(request, 'محصول با موفقیت اضافه شد')
            return redirect('seller_dashboard')
    else:
        form = ProductForm()
    
    return render(request, 'seller_panel/add_product.html', {'form': form})
