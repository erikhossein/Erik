from django.urls import path
from . import views

urlpatterns = [
    path('change-password/', views.change_password, name='change_password'),
    path('sales-chart/', views.sales_chart, name='sales_chart'),
    path('manage-stock/', views.manage_stock, name='manage_stock'),
    path('sales-chart-data/', views.sales_chart_data, name='sales_chart_data'),
    path('', views.seller_dashboard, name='seller_dashboard'),
    path('edit-profile/', views.edit_profile, name='edit_profile'),
    path('add-product/', views.add_product, name='add_product'),
    path('edit-product/<int:product_id>/', views.edit_product, name='edit_product'),
    path('delete-product/<int:product_id>/', views.delete_product, name='delete_product'),
    path('orders/', views.seller_orders, name='seller_orders'),
]
