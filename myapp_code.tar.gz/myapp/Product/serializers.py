from rest_framework import serializers
from .models import Product, Industry, ProductImage

class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ['id', 'image', 'is_main']

class ProductSerializer(serializers.ModelSerializer):
    images = ProductImageSerializer(many=True, read_only=True)
    
    class Meta:
        model = Product
        fields = ['id', 'title', 'price', 'descriptions', 'product_type', 'industry', 'store_owner', 'stock', 'active', 'created_at', 'discount_percent', 'images']

class IndustrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Industry
        fields = ['id', 'name']

class ProductSerializerFull(serializers.ModelSerializer):
    images = ProductImageSerializer(many=True, read_only=True)
    industry_name = serializers.CharField(source='industry.name', read_only=True)
    
    class Meta:
        model = Product
        fields = '__all__'

class ProductSerializerShow(serializers.ModelSerializer):
    images = ProductImageSerializer(many=True, read_only=True)
    industry_name = serializers.CharField(source='industry.name', read_only=True)
    store_owner_name = serializers.CharField(source='store_owner.username', read_only=True)
    
    class Meta:
        model = Product
        fields = ['id', 'title', 'price', 'descriptions', 'product_type', 'stock', 'discount_percent', 'images', 'industry_name', 'store_owner_name']
