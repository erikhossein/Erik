from django.db import models
from django.conf import settings

class Industry(models.Model):
    name = models.CharField(max_length=100)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='children')
    
    def __str__(self):
        return self.name

class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(unique=True)
    
    def __str__(self):
        return self.name

class Product(models.Model):
    PRODUCT_TYPES = (
        ('Physical', 'فیزیکی'),
        ('Digital', 'دیجیتال'),
    )
    
    title = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    descriptions = models.TextField()
    product_type = models.CharField(max_length=10, choices=PRODUCT_TYPES, default='Physical')
    industry = models.ForeignKey(Industry, on_delete=models.SET_NULL, null=True, blank=True)
    store_owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='products')
    stock = models.IntegerField(default=0)
    low_stock_threshold = models.IntegerField(default=5)
    active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    discount_percent = models.IntegerField(default=0)
    discount_start = models.DateTimeField(null=True, blank=True)
    discount_end = models.DateTimeField(null=True, blank=True)
    tags = models.ManyToManyField(Tag, blank=True, related_name='products')
    
    def __str__(self):
        return self.title
    
    def get_discounted_price(self):
        if self.discount_percent > 0:
            return self.price * (100 - self.discount_percent) / 100
        return self.price
    
    def is_on_discount(self):
        from django.utils import timezone
        if self.discount_percent > 0 and self.discount_start and self.discount_end:
            now = timezone.now()
            return self.discount_start <= now <= self.discount_end
        return self.discount_percent > 0

class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='product_images')
    image = models.ImageField(upload_to='products/')
    is_main = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Image for {self.product.title}"

class ProductView(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='views')
    ip = models.GenericIPAddressField()
    session_key = models.CharField(max_length=40, blank=True, null=True)
    viewed_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.product.title} - {self.viewed_at}"

    @property
    def average_rating(self):
        from review.models import Review
        reviews = Review.objects.filter(product=self)
        if reviews.exists():
            return reviews.aggregate(models.Avg('rating'))['rating__avg'] or 0
        return 0
